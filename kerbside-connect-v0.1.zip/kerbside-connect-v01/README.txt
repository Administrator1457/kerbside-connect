KERBSIDE CONNECT v0.1 PROTOTYPE

This is a functional browser/PWA prototype. It stores reports locally on the device for now; it does not yet have a shared online database, live GPS, authentication, moderation backend, push notifications, or production maps.

To test: open index.html in a modern browser. For Android installation as a PWA, serve this folder over HTTPS (or use a local development server).

Next production steps:
1. Replace local storage with a secure hosted database/API.
2. Add authentication and moderation.
3. Add a production map provider and approximate location handling.
4. Add image upload with privacy filtering and storage rules.
5. Verify council data and links.
6. Draft Terms of Use and Privacy Policy.
7. Package Android release (AAB), test, and publish through Google Play Console.
8. Later package iOS version.

The prototype intentionally labels community reports as unverified and does not claim council affiliation.
